
package movieticks;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CinemaTicketsApp extends JFrame {

    private JComboBox<String> movieComboBox;
    private JTextField ticketPriceField, numTicketsField;
    private JTextArea reportArea;
    private String output = "";

    public CinemaTicketsApp() {
        initComponents();
    }

    private void initComponents() {
        // Set up frame
        setTitle("Cinema Ticket Sales");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 500);
        setLocationRelativeTo(null);

        // Combo Box for Movie Selection
        JLabel movieLabel = new JLabel("Select Movie:");
        movieComboBox = new JComboBox<>(new String[]{"Oppenheimer", "Napoleon", "Damsel"});

        // Text fields for Ticket Price and Number of Tickets
        JLabel ticketPriceLabel = new JLabel("Ticket Price:");
        ticketPriceField = new JTextField(10);

        JLabel numTicketsLabel = new JLabel("Number of Tickets:");
        numTicketsField = new JTextField(10);

        // Text area for report output
        reportArea = new JTextArea(10, 30);
        reportArea.setEditable(false);

        // Set up menu bar with "File" and "Tools" menus
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(evt -> System.exit(0));
        fileMenu.add(exitMenuItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processMenuItem = new JMenuItem("Process");
        processMenuItem.addActionListener(this::processReport);

        JMenuItem clearMenuItem = new JMenuItem("Clear");
        clearMenuItem.addActionListener(evt -> clearFields());

        toolsMenu.add(processMenuItem);
        toolsMenu.add(clearMenuItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);

        // Arrange components on the frame
        JPanel panel = new JPanel(new GridLayout(4, 2, 5, 5));
        panel.add(movieLabel);
        panel.add(movieComboBox);
        panel.add(ticketPriceLabel);
        panel.add(ticketPriceField);
        panel.add(numTicketsLabel);
        panel.add(numTicketsField);

        JScrollPane scrollPane = new JScrollPane(reportArea);

        add(panel, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);
    }

    private void processReport(ActionEvent evt) {
        String movieName = (String) movieComboBox.getSelectedItem();
        try {
            double ticketPrice = Double.parseDouble(ticketPriceField.getText());
            int numTickets = Integer.parseInt(numTicketsField.getText());

            MovieTicketData data = new MovieTicketData(movieName, ticketPrice, numTickets);
            MovieTicks movieTicks = new MovieTicks();

            if (movieTicks.ValidateData(data)) {
                double totalAmount = movieTicks.CalculateTotalTicketPrice(numTickets, ticketPrice);
                output = "Movie Ticket Sales Report:\n";
                output += "Movie: " + movieName + "\n";
                output += "Number of Tickets: " + numTickets + "\n";
                output += "Ticket Price: R" + ticketPrice + "\n";
                output += "Total Amount (incl. VAT): R" + totalAmount + "\n";

                reportArea.setText(output);
                saveToFile();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid data. Please check your input.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for ticket price and quantity.");
        }
    }

    private void saveToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("movie_ticket_report.txt"))) {
            writer.write(output);
            JOptionPane.showMessageDialog(this, "Report saved successfully.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving report.");
        }
    }

    private void clearFields() {
        movieComboBox.setSelectedIndex(0);
        ticketPriceField.setText("");
        numTicketsField.setText("");
        reportArea.setText("");
        output = "";
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CinemaTicketsApp().setVisible(true));
    }
}

