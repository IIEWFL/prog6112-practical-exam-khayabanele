
package movieticks;


public class MovieTicketData {
    
        public String movieName;
        public double ticketPrice;
        public int numTickets;

        public MovieTicketData(String movieName, double ticketPrice, int numTickets) {
            this.movieName = movieName;
            this.ticketPrice = ticketPrice;
            this.numTickets = numTickets;
        }

        public String getMovieName() {
            return movieName;
        }

        public double getTicketPrice() {
            return ticketPrice;
        }

        public int getNumTickets() {
            return numTickets;
        }
    }
 

