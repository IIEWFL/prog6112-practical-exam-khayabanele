
package movieticks;


public class MovieTicks implements IMovieTicks {

    private static final double VAT_RATE = 0.14;

    @Override
    public double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        double totalPrice = numberOfTickets * ticketPrice;
        return totalPrice + (totalPrice * VAT_RATE);
    }

    @Override
    public boolean ValidateData(MovieTicketData movieTicketData) {
        return movieTicketData.getMovieName() != null && !movieTicketData.getMovieName().isEmpty()
                && movieTicketData.getTicketPrice() > 0
                && movieTicketData.getNumTickets() > 0;
    }
}


