
package movieticks;


public interface IMovieTicks {
      double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice);

        boolean ValidateData(MovieTicketData movieTicketData);
    }


