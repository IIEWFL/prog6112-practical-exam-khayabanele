
package movietickets;

public class MovieTickets implements IMovieTickets {

        
        //2D array for storing monthly sales
        static int[][] monthlySales = {
            {3000,1500,1700},       //totals for Oppenheimer and Napoleon
            {3500,1200,1600}
        
        };
    // Array of movie names
    static String[] movieNames = {"Napoleon", "Oppenheimer"};

    // Array of months
    static String[] months = {"JAN", "FEB", "MAR"};

    // Array to store total sales for each movie
    int[] movieTotals = new int[2];

    @Override
    public int TotalMovieSales(int[] movieTicketSales) {
        int total = 0;
        
        for (int sale : movieTicketSales) {
            total += sale;
        }
        return total;
    }

    @Override
    public String TopMovie(String[] movies, int[] totalSales) {
        int topIndex = 0;
        if (totalSales[1] > totalSales[0]) {
            topIndex = 1;
        }
        return movies[topIndex];
    }

    
    public void printReport() { //  Printing the movie report
        String output = "\nMOVIE TICKET SALES REPORT\n";
        output += String.format("%-15s %-15s %-15s %-15s\n", "", months[0], months[1], months[2]);
        output += "-------------------------------------------------------------\n";

       
        for (int i = 0; i < monthlySales.length; i++) {  // Printing monthly ticket sales totals
            output += String.format("%-15s %-15d %-15d %-15d\n",
                    movieNames[i], monthlySales[i][0], monthlySales[i][1], monthlySales[i][2]);
        }

       
        for (int i = 0; i < monthlySales.length; i++) {  // Calculating total ticket sales and printing 
            int totalSales = TotalMovieSales(monthlySales[i]);
            movieTotals[i] = totalSales;  // Storing movie's total sales
            output += "\nTotal sales for " + movieNames[i] + " = " + totalSales;
        }
        output += "\n";

       
        String topMovie = TopMovie(movieNames, movieTotals);  // Finding the top-performing movie
        output += "\n\nTop-performing movie: " + topMovie;

        
        System.out.println(output);
    }
}


