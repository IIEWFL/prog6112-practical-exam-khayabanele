
package movietickets;


public class TestMovieTickets {

    
    public static void main(String[] args) {
        MovieTickets tickets = new MovieTickets();
        // Generate and display the movie ticket sales report
        tickets.printReport();
    }
}
 
  
    

