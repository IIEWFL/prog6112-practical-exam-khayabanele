
package movietickets;
import org.junit.
import org.junit.Test;


public class MovieTicketsTest {
    
    
    
        @Test
        void CalculateTotalSales_ReturnsExpectedTotalSales() {
            MovieTickets tickets = new MovieTickets();
            int[] napoleonSales = {3000, 1500, 1700};  // January, February, March ticket sales for Napoleon
            int expectedTotalSales = 6200; // Expected total is 3000 + 1500 + 1700

            int actualTotalSales = tickets.TotalMovieSales(napoleonSales);
            assertEquals(expectedTotalSales, actualTotalSales,
                    "Total sales calculation should return the correct total for Napoleon movie sales.");
        }

        @Test
        void TopMovieSales_ReturnsTopMovie() {
            // Arrange
            MovieTickets tickets = new MovieTickets();
            String[] movieNames = {"Napoleon", "Oppenheimer"};
            int[] totalSales = {6200, 6300};  // Total sales for each movie
            String expectedTopMovie = "Oppenheimer"; // Oppenheimer has higher sales

            // Act
            String actualTopMovie = tickets.TopMovie(movieNames, totalSales);

            // Assert
            assertEquals(expectedTopMovie, actualTopMovie,
                    "Top movie determination should return the movie with the highest sales.");
        }

}