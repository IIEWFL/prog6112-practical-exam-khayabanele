/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package movietickets;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Dell
 */
public class IMovieTicketsTest {
    
    public IMovieTicketsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of TotalMovieSales method, of class IMovieTickets.
     */
    @Test
    public void testTotalMovieSales() {
        System.out.println("TotalMovieSales");
        int[] movieTicketSales = null;
        IMovieTickets instance = new IMovieTicketsImpl();
        int expResult = 0;
        int result = instance.TotalMovieSales(movieTicketSales);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of TopMovie method, of class IMovieTickets.
     */
    @Test
    public void testTopMovie() {
        System.out.println("TopMovie");
        String[] movies = null;
        int[] totalSales = null;
        IMovieTickets instance = new IMovieTicketsImpl();
        String expResult = "";
        String result = instance.TopMovie(movies, totalSales);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class IMovieTicketsImpl implements IMovieTickets {

        public int TotalMovieSales(int[] movieTicketSales) {
            return 0;
        }

        public String TopMovie(String[] movies, int[] totalSales) {
            return "";
        }
    }
    
}
